extern double dlange_ ( const char * const norm,
		const int * const m,
		const int * const n,
		const double * A,
		const int * const lda,
              	double * const work
		);
