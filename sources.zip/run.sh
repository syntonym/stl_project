#!/bin/bash
INSTALL_PREFIX=./_install bash plasma_lapack_blas.sh
